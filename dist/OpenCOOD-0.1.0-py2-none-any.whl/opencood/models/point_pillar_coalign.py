"""
CoAlign Fusion Network is multiscale att fusion with ResNet Backbone
"""

from opencood.models.point_pillar_baseline_multiscale import PointPillarBaselineMultiscale

class CoAlign(PointPillarBaselineMultiscale):
    pass